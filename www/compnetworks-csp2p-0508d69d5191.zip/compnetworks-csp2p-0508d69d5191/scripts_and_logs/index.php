<html>
<body>

PA1 download statistics are below. The first column has the last four digits of your student ID. The meaning of the remaining columns is documented <a href="stats_columns.html">here</a>

<?php include 'ShowStats.php';?>

</body>
</html>
